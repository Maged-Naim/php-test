<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <div class="container">
        <div class="header">
            <h2>Home Page</h2>
        </div>
        <div class="content">

            <?php if (isset($_SESSION['success'])) : ?>

                <div class="success">
                    <h3>
                    
                        <?php
                        echo $_SESSION['success'] . " " . $_SESSION['name'];
                        
                        unset($_SESSION['success']);
                        ?>
                    </h3>
                </div>
            <?php endif ?>

            <?php if (isset($_SESSION['name'])) : ?>
                
                <span>
                    <form action="logout.php" method="POST" style="color: red;">
                        <button type="submit" name="submit" class="btn">Logout</button>
                    </form>
                </span>
            <?php endif ?>

        </div>
    </div>
</body>

</html>