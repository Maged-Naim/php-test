<?php include('server.php') ?>
<!DOCTYPE html>
<html>

<head>
  <title>Login & Register </title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>
  <div class="cont">
    <form action="login.php" method="post">
      <?php include('errors.php'); ?>
      <div class="form sign-in">

        <h2>Sign In</h2>
        <label>
          <span>Email Address</span>
          <input type="email" name="email">
        </label>
        <label>
          <span>Password</span>
          <input type="password" name="password">
        </label>
        <button type="submit" name="login" class="submit" type="button">Sign In</button>

    </form>

  </div>

  <div class="sub-cont">
    <div class="img">
      <div class="img-text m-up">
        <h2>New here?</h2>
        <p>Sign up and discover great amount of new opportunities!</p>
      </div>
      <div class="img-text m-in">
        <h2>Do you have an account?</h2>
        <p>If you already has an account, just sign in.</p>
      </div>
      <div class="img-btn">
        <span class="m-up">Sign Up</span>
        <span class="m-in">Sign In</span>
      </div>
    </div>
    <form action="register.php" method="post">
      <div class="form sign-up">
        <?php include('errors.php'); ?>
        <h2>Sign Up</h2>
        <label>
          <span>Name</span>
          <input type="text" name="name">

        </label>
        <label>
          <span>Email</span>
          <input type="email" name="email">
        </label>
        <label>
          <span>Password</span>
          <input type="password" name="password">
        </label>
        <label>
          <span>Phone</span>
          <input type="tel" name="phone" max="11">
        </label>
        <label>
          <span>Address</span>
          <input type="text" name="address">
        </label>
        <button type="submit" name="register" class="submit">Sign Up Now</button>
      </div>
  </div>
  </div>
  </form>
  <script type="text/javascript" src="script.js"></script>
</body>

</html>