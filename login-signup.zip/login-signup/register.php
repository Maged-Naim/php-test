<?php session_start(); ?>

<?php
include('server.php');

$name = "";
$email = "";
$password = "";
$phone = "";
$address = "";
$errors = array();
if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $pass = mysqli_real_escape_string($con, $_POST['password']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $address = mysqli_real_escape_string($con, $_POST['address']);

    if (empty($name)) {
        array_push($errors, "Name is Required");
    }
    if (empty($email)) {
        array_push($errors, "Email is Required");
    }
    if (empty($pass)) {
        array_push($errors, "Password is Required");
    }
    if (empty($phone)) {
        array_push($errors, "phone is Required");
    }
    if (empty($address)) {
        array_push($errors, "Address is Required");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        array_push($errors, "Pleaase Insert a valid email");
    }
    if (count($errors == 0)) {
        $password = md5($pass);
        $sql = "INSERT INTO users(name, email, password, phone, address) VALUES('$name', '$email', '$password', '$phone', '$address')";

        if (mysqli_query($con, $sql)) {
            $_SESSION['name'] = $name;
            $_SESSION['success'] = "Welcome ";
            header("Location: ../home.php?signup=success");
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($con);
        }
    }
}


