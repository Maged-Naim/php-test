<?php
session_start();
?>

<?php

include('server.php');

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $pass = mysqli_real_escape_string($con, $_POST['password']);
  
    if (empty($email)) {
        array_push($errors, "Email is Required");
    }
    if (empty($pass)) {
        array_push($errors, "Password is Required");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        array_push($errors, "Pleaase Insert a valid email");
    }

  
    
    if (count($errors == 0)) {
        $password = md5($pass);
        
        $sql = "SELECT * FROM users WHERE email='$email' AND  password='$pass'";
         
        $result = mysqli_query($con, $sql);
        $resultCheck = mysqli_num_rows($result);
    	if($resultCheck < 1){
    		header("Location: ../index.php?login=error");
            exit();
        }else{

    		if($row = mysqli_fetch_assoc($result)){
                $pwdCheck = password_verify($password , $row['password']);
                
    			if($pwdCheck == false){
    				header("Location: ../index.php?login=error");
                    exit();
    			}elseif($pwdCheck == true){
    				$_SESSION['name'] = $row['name'];
    				$_SESSION['success'] = 'welcome';
                     
    				header("Location: ../home.php");
                    exit();
    			}
    		}
    	}

    }
}




?>