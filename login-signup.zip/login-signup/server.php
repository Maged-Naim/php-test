<?php
   session_start();
?>
<?php
 $con = mysqli_connect('localhost', 'maged', '', 'loginsystem');
 if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
  }
 



?>